# Render deployment guide

This repository contains a FastAPI backend and a Streamlit frontend. The original ZIP had no Streamlit entry point; `frontend/app.py` is a minimal UI added for deployment and calls the existing API routes.

## Render services
Create a managed PostgreSQL database and two **Web Services** from the same GitHub repository. Use the same Render region for both services and the database.

### 1. PostgreSQL database
Create a Render PostgreSQL database. Copy its **Internal Database URL** for the backend service. Keep credentials private.

### 2. Backend Web Service
- Runtime: Python
- Root Directory: `backend`
- Build Command: `pip install -r requirements.txt`
- Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
- Health Check Path: `/health`
- Environment variables:
  - `DATABASE_URL`: Internal Database URL from the Render PostgreSQL database
  - `SECRET_KEY`: generate a long random secret (at least 32 random bytes)
  - `ALGORITHM`: `HS256`
  - `ACCESS_TOKEN_EXPIRE_MINUTES`: `30`

### 3. Frontend Web Service
- Runtime: Python
- Root Directory: `frontend`
- Build Command: `pip install -r requirements.txt`
- Start Command: `streamlit run app.py --server.address 0.0.0.0 --server.port $PORT`
- Environment variable `API_BASE_URL`: backend's **Internal URL**, e.g. `http://<backend-service-name>:8000` (use the service's actual private hostname/port shown by Render).

### 4. Create the first administrator
After the backend is deployed and the database is reachable, open the backend service Shell in Render and run:

```bash
python create_admin.py
```

Enter the administrator email and a strong password when prompted. The command creates the first admin user. Do not put admin passwords in source code or commit them to GitHub.

### 5. Verify
- Open `https://<backend-service>.onrender.com/health` and confirm `{"status":"healthy"}`.
- Open `https://<backend-service>.onrender.com/docs` to inspect the API.
- Open the frontend service URL and sign in with the admin account.
- Add a test book and verify it appears in the catalogue.

## Important notes
- Commit and push these deployment changes to the GitHub repository before creating Render services, or deploy from a connected fork containing these files.
- Render's PostgreSQL is used for production; the original MySQL environment variables remain supported for local development.
- This starter UI exposes only the main existing API workflows. Test all operations before real library use. Configure database backups and a strong secret before production.
