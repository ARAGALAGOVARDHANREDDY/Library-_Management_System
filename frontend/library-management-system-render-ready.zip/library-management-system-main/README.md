# College Library Management System

Python application using FastAPI, Streamlit and SQLAlchemy. The backend supports MySQL for local development and PostgreSQL for Render deployment.

- Backend API: `backend/main.py`
- Streamlit frontend: `frontend/app.py`
- Deployment instructions: `RENDER_DEPLOYMENT.md`

See the deployment guide before publishing.
